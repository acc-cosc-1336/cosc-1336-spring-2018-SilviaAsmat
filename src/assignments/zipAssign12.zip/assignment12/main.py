from src.assignments.assignment12.win import Win
#Create a main file and create an instance of the Win class.

win = Win()